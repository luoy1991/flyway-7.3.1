 create table account(
     id int primary key auto_increment,
     name varchar(40),
     money float
 );
