Welcome to Flyway
-----------------
Database Migrations Made Easy


Documentation
-------------
You can find getting started guides and reference documentation at https://flywaydb.org


Contributing
------------
Here is the info on how you can contribute in various ways to the project: https://flywaydb.org/documentation/contribute/


License
-------
Copyright (C) 2010-2020 Boxfuse GmbH

Flyway Community Edition    : https://flywaydb.org/licenses/flyway-community
Flyway 30 day limited trial : https://flywaydb.org/licenses/flyway-trial
Flyway Teams Edition   : https://flywaydb.org/licenses/flyway-teams

Flyway is a registered trademark of Boxfuse GmbH.